<?php
/**
 * Created by PhpStorm.
 * User: ciub_
 * Date: 28.05.2020
 * Time: 15:40
 */
// Crearea unui formular
<form action = "script.php" method = "post">
    Nume:<input type="text" name="nume" />
    <br/><input type="submit" nume="submit"
    value="Trimitere formular"/>
    </form>;
