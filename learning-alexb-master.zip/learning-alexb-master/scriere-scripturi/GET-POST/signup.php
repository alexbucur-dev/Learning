<?php
/**
 * Created by PhpStorm.
 * User: ciub_
 * Date: 03.06.2020
 * Time: 15:32
 */

echo $_POST['username'];
echo $_POST['password'];
