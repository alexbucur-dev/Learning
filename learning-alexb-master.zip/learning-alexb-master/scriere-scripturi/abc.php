<?php
/**
 * Created by PhpStorm.
 * User: ciub_
 * Date: 27.05.2020
 * Time: 09:02
 */

print_r('abggc');
echo "Hello world";

// Comentariu
echo "Asa se creaza un comentariu";
echo "sau, un comentariu cu mai multe linii:";
/*linia1
linia2
linia3
*/



phpinfo();die;