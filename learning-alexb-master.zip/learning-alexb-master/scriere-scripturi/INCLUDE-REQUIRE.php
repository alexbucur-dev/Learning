<?php
/**
 * Created by PhpStorm.
 * User: ciub_
 * Date: 03.06.2020
 * Time: 14:19
 */

<html>
<head>
<meta charset = "UTF-8">
    <title> Document </title>

</head>
<body>
include 'navigare.html';
<h1>dsadsadadqw</h1>

</body>
</html>