<?php
/**
 * Created by PhpStorm.
 * User: ciub_
 * Date: 30.05.2020
 * Time: 16:45
 */

$var7 = 20;
$var8 = 20;

if ($var7 >= $var8){
    echo 'prima variabila este mai mare sau egala cu a 2-a';
}
else{
    echo 'a doua variabila este mai mare ca prima';
}

// O P E R A T O R I       L O G I C I
$var1 = 20;
$var2 = 30;

if($var1==$var2 || $var1>10) {
    echo 'OK';
}else {
    echo 'FALS';
}

/*
sau: "||" / "or"
si: "&&" / "and"
"xor" - va executa codul daca DOAR UNA este adevarata
*/